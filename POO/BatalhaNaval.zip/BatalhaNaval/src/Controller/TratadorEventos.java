package Controller;

public class TratadorEventos {
	
	//metodos
	//valida Ataque...
	
	
	//duas telas ( uma com o posicionamento das embarcações e outras apenas com agua tiro ou pedaço de navio destruido)
	

}
