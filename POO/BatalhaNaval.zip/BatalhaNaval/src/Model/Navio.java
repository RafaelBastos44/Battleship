package Model;

public class Navio {
	
	//submarino
	//hidroaviao
	///cruzador
	//
	
	// nao reposicionar os navios
	
	// se tentar colocar em uma posição que nao pd pintar a interface grafica de vermelho
	
	//

}
