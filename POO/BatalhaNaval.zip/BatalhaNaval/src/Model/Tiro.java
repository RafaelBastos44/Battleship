package Model;

public class Tiro {

}
